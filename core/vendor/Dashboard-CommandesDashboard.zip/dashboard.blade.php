<?php
		ob_start();
		/**
		 * DashboardBuilder
		 *
		 * @author Diginix Technologies www.diginixtech.com
		 * Support <support@dashboardbuider.net> - https://www.dashboardbuilder.net
		 * @copyright (C) 2016-2023 Dashboardbuilder.net
		 * @version 6.5
		 * @license: This code is under MIT license, you can find the complete information about the license here: https://dashboardbuilder.net/code-license
		 */
		$_SESSION["DF"]="";
		$_SESSION["NF0"]="";
		$_SESSION["NF"]="";
		include("inc/dashboard_dist.php");  // copy this file to inc folder 
		?>
		<!DOCTYPE html>
		<html lang="fr-fr" dir="ltr">
		<head>
			<meta http-equiv="X-UA-Compatible" content="IE=edge">
			<meta name="viewport" content="width=device-width, initial-scale=1">
			<script src="https://cdn.jsdelivr.net/gh/DashboardBuilder/cdn@master/v55/dashboard.min.js"></script> <!-- copy this file to assets/js folder -->
			<link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/DashboardBuilder/cdn@master/v55/bootstrap.min.css"> <!-- Bootstrap 5 CSS file, change the path accordingly -->
			<link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/DashboardBuilder/cdn@master/v55/font-awesome.min.css">  <!-- Font Awesome CSS file, change the path accordingly -->
			<link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/DashboardBuilder/cdn@master/v55/bootstrap-select.min.css"  /> <!-- copy this file to assets/css folder -->
			<link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/DashboardBuilder/cdn@master/v55/jquery-ui.css"> <!-- copy this file to assets/css folder -->
			<link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/DashboardBuilder/cdn@master/v55/vanilla-datetimerange-picker.css">  <!-- copy this file to assets/css folder -->
			<script src="https://cdn.jsdelivr.net/gh/DashboardBuilder/cdn@master/v55/jquery.min.js"></script> <!-- copy this file to assets/js folder -->
			<script src="https://cdn.jsdelivr.net/gh/DashboardBuilder/cdn@master/v55/bootstrap.bundle.min.js"></script> <!-- copy this file to assets/js folder -->
			<script src="https://cdn.jsdelivr.net/gh/DashboardBuilder/cdn@master/v55/bootstrap-select.min.js" ></script> <!-- copy this file to assets/js folder -->
			<script src="https://cdn.jsdelivr.net/gh/DashboardBuilder/cdn@master/v55/jquery-ui.js"></script> <!-- copy this file to assets/js folder -->
			<script src="https://cdn.jsdelivr.net/gh/DashboardBuilder/cdn@master/v55/moment.min.js"></script> <!-- copy this file to assets/js folder -->
			<script src="https://cdn.jsdelivr.net/gh/DashboardBuilder/cdn@master/v55/vanilla-datetimerange-picker.js"></script> <!-- copy this file to assets/js folder -->
		<style>
		@media screen and (min-width: 960px) {
		.id0 {position:absolute; top:5px;}
		.id1 {position:absolute; top:5px;}
		
		}
		.card-header {line-height:0.7em;}
		#number {font-size:32px; font-weight:bold;text-align:center;margin-top:-10px;}
		#number_legand {font-size:11px; text-align:center;}
		.panel-body {  box-shadow: 5px 5px 35px  #e0e0e0;color:#787b80;}
		.page-header {margin-top:-30px;}.dropdown-toggle{font-size:12px;line-height:12px;}
			.selectoption {font-size:12px !important;}
			.bs-searchbox > input {
			  font-size: 12px;
			  height:26px;
			}
		</style>

		<div class="col col-lg-12 col-md-12 col-xs-12 card card-default position-relative" id="showhide-filterid" style="margin:0;padding:0;">
		<div class="card-header m-0 p-1">
		<span id="datefilteridshow"></span><span id="numberfilteridshow"></span><span id="filteridshow"></span>
		<button type="submit" class="btn btn-sm btn-link text-dark close" onClick="window.location.href = window.location.href;" style="font-size:14px;" ><span id="filterrefresh" class="fa fa-refresh" style="float:right;"></span></button>
		</div>
		</div>
		<?php
		// for chart #1
		$data = new dashboardbuilder(); 
$data->type[0]=  "bar";

		$data->legacy = "";
		$data->source =  "Database"; 
		$data->rdbms =  "mysql"; 
		$data->servername =  "https://localhost:3306";
		$data->username =  "sicaqees_pouletbinuser";
		$data->password =  "sx/BJlLMhUn2mEVKF0paYA==";
		$data->dbname =  "sicaqees_pouletbiniNew";
		$data->toImage = "Téléchargez le graphique";
		$data->zoomin = "Agrandir";
		$data->zoomout = "Dézoomer";
		$data->autoscale = "Réinitialiser";
		$data->filterlabel = "Filtre";
		$data->forecastlabel = "Prévoir";
		$data->filter = "true";
		$data->xaxisSQL[0]=  "SELECT count(id) as yaxis, DATE_FORMAT(estimate_date, ^%Y/%m/%d^) as xaxis FROM livraison_infos GROUP BY estimate_date;";
$data->xaxisCol[0]=  "xaxis";
$data->xsort[0]=  "";
$data->xmodel[0]=  "";
$data->forecast[0]=  "0";
$data->yaxisSQL[0]=  "SELECT count(id) as yaxis, DATE_FORMAT(estimate_date, ^%Y/%m/%d^) as xaxis FROM livraison_infos GROUP BY estimate_date;";
$data->yaxisCol[0]=  "yaxis";
$data->ysort[0]=  "";
$data->ymodel[0]=  "";

		$data->name = "0";
		$data->title = " Graphique";
		$data->orientation = "v";
		$data->dropdown = "false";
		$data->side = "left";
		$data->toImage = "Téléchargez le graphique";
		$data->zoomin = "Agrandir";
		$data->zoomout = "Dézoomer";
		$data->autoscale = "Réinitialiser";
		$data->filter = "true";
		$data->forecastlabel = "Prévoir";
		$data->legposition = "";
		$data->xaxistitle = "Date de livraison";
		$data->yaxistitle = "Nombre de commande";
		$data->datalabel = "false";
		$data->showgrid = "true";
		$data->showline = "true";
		$data->tablefontsize = "9";
		$data->height = "223";
		$data->width = "0";
		$data->col = "0";
		
		$data->plot = "dynamic";
		$data->font_color = "";
		$data->bg_color = "";
		$data->color[0]=  "#b3008c";
$result[0] = $data->result();
		// for chart #2
		$data = new dashboardbuilder(); 
$data->type[0]=  "area";

		$data->legacy = "";
		$data->source =  "Database"; 
		$data->rdbms =  "mysql"; 
		$data->servername =  "https://localhost:3306";
		$data->username =  "sicaqees_pouletbinuser";
		$data->password =  "sx/BJlLMhUn2mEVKF0paYA==";
		$data->dbname =  "sicaqees_pouletbiniNew";
		$data->toImage = "Téléchargez le graphique";
		$data->zoomin = "Agrandir";
		$data->zoomout = "Dézoomer";
		$data->autoscale = "Réinitialiser";
		$data->filterlabel = "Filtre";
		$data->forecastlabel = "Prévoir";
		$data->filter = "true";
		$data->xaxisSQL[0]=  "SELECT count(id) as yaxis, DATE_FORMAT(estimate_date, ^%Y/%m/%d^) as xaxis FROM livraison_infos GROUP BY estimate_date;";
$data->xaxisCol[0]=  "xaxis";
$data->xsort[0]=  "";
$data->xmodel[0]=  "";
$data->forecast[0]=  "0";
$data->yaxisSQL[0]=  "SELECT count(id) as yaxis, DATE_FORMAT(estimate_date, ^%Y/%m/%d^) as xaxis FROM livraison_infos GROUP BY estimate_date;";
$data->yaxisCol[0]=  "yaxis";
$data->ysort[0]=  "";
$data->ymodel[0]=  "";

		$data->name = "1";
		$data->title = " Graphique";
		$data->orientation = "v";
		$data->dropdown = "false";
		$data->side = "left";
		$data->toImage = "Téléchargez le graphique";
		$data->zoomin = "Agrandir";
		$data->zoomout = "Dézoomer";
		$data->autoscale = "Réinitialiser";
		$data->filter = "true";
		$data->forecastlabel = "Prévoir";
		$data->legposition = "";
		$data->xaxistitle = "Date de livraison";
		$data->yaxistitle = "Nombre de commande";
		$data->datalabel = "false";
		$data->showgrid = "true";
		$data->showline = "true";
		$data->tablefontsize = "9";
		$data->height = "225";
		$data->width = "0";
		$data->col = "1";
		
		$data->plot = "dynamic";
		$data->font_color = "";
		$data->bg_color = "";
		$data->color[0]=  "#0cb68c";
$result[1] = $data->result();
		<style>
		@media screen and (min-width: 960px) {
		.id0 {position:absolute; top:5px;}
		.id1 {position:absolute; top:5px;}
		
		}
		.card-header {line-height:0.7em;}
		#number {font-size:32px; font-weight:bold;text-align:center;margin-top:-10px;}
		#number_legand {font-size:11px; text-align:center;}
		.panel-body {  box-shadow: 5px 5px 35px  #e0e0e0;color:#787b80;}
		.page-header {margin-top:-30px;}.dropdown-toggle{font-size:12px;line-height:12px;}
			.selectoption {font-size:12px !important;}
			.bs-searchbox > input {
			  font-size: 12px;
			  height:26px;
			}
		</style>

		<div class="col col-lg-12 col-md-12 col-xs-12 card card-default position-relative" id="showhide-filterid" style="margin:0;padding:0;">
		<div class="card-header m-0 p-1">
		<span id="datefilteridshow"></span><span id="numberfilteridshow"></span><span id="filteridshow"></span>
		<button type="submit" class="btn btn-sm btn-link text-dark close" onClick="window.location.href = window.location.href;" style="font-size:14px;" ><span id="filterrefresh" class="fa fa-refresh" style="float:right;"></span></button>
		</div>
		</div> 
		function Dashboard-CommandesDashboard($result) {?>
		<div class="container-fluid main-container position-relative">
		<div class="col col-md-12 col-lg-12 col-xs-12">
			<div class="row my-4">
			<div class="col-md-6 col-xs-12  id0">
			<div class="card-default shadow">
				<div class="card-body bgcolor">
				<span class="d-flex justify-content-start mx-2 font-color"> Graphique</span>
					<?php echo $result[0];?>
				</div>
			</div>
			</div>
			<div class="col-md-5 col-xs-12 offset-md-7 id1">
			<div class="card-default shadow">
				<div class="card-body bgcolor">
				<span class="d-flex justify-content-start mx-2 font-color"> Graphique</span>
					<?php echo $result[1];?>
				</div>
			</div>
			</div>
				</div>
		</div>
		</div>
		<!-- DF Filter -->
		<script>
		<?php echo $_SESSION["NF0"];?>
		<?php echo $_SESSION["NF"];?>

		<?php 
		if (!empty($_SESSION["DF"])) { ?>
		window.addEventListener('load', function (event) {
													let drp = new DateRangePicker('datetimerange-input1',
														{
															timePicker: false,
															alwaysShowCalendars: true,
															ranges: {
																'Aujourd`hui': [moment().startOf('day'), moment().endOf('day')],
																'Hier': [moment().subtract(1, 'days').startOf('day'), moment().subtract(1, 'days').endOf('day')],
																'Les 7 derniers jours': [moment().subtract(6, 'days').startOf('day'), moment().endOf('day')],
																'Ce mois-ci': [moment().startOf('month').startOf('day'), moment().endOf('month').endOf('day')],
															},
															locale: {
																direction: 'ltr',
																format: 'YYYY-MM-DD',
																applyLabel: 'Appliquer',
																cancelLabel: 'Annuler',
																customRangeLabel: 'Gamme personnalisée',
															}
														},
														function (start, end) {
		<?php echo $_SESSION["DF"];?>

														})
												});
		moment.locale('en', {
						months : 'janvier_février_mars_avril_mai_juin_juillet_aout_septembre_octobre_novembre_décembre'.split('_'),
						monthsShort : 'jan_fév_mar_avr_mai_jun_jul_aou_sep_oct_nov_déc'.split('_'),
						monthsParseExact : true,
						weekdays : 'dimanche_lundi_mardi_mercredi_jeudi_vendredi_samedi'.split('_'),
						weekdaysShort : 'dim_lun_mar_mer_jeu_ven_sam'.split('_'),
						weekdaysMin : 'di_lu_ma_me_je_ve_sa'.split('_'),
						weekdaysParseExact : true,
						longDateFormat : {
							LT : 'HH:mm',
							LTS : 'HH:mm:ss',
							L : 'DD/MM/YYYY',
							LL : 'D MMMM YYYY',
							LLL : 'D MMMM YYYY HH:mm',
							LLLL : 'dddd D MMMM YYYY HH:mm'
						},
						calendar : {
							sameDay : '[Aujourd’hui à] LT',
							nextDay : '[Demain à] LT',
							nextWeek : 'dddd [à] LT',
							lastDay : '[Hier à] LT',
							lastWeek : 'dddd [dernier à] LT',
							sameElse : 'L'
						},
						relativeTime : {
							future : 'dans %s',
							past : 'il y a %s',
							s : 'quelques secondes',
							m : 'une minute',
							mm : '%d minutes',
							h : 'une heure',
							hh : '%d heures',
							d : 'un jour',
							dd : '%d jours',
							M : 'un mois',
							MM : '%d mois',
							y : 'un an',
							yy : '%d ans'
						},
						dayOfMonthOrdinalParse : /\d{1,2}(er|e)/,
						ordinal : function (number) {
							return number + (number === 1 ? 'er' : 'e');
						},
						meridiemParse : /PD|MD/,
						isPM : function (input) {
							return input.charAt(0) === 'M';
						},

						meridiem : function (hours, minutes, isLower) {
							return hours < 12 ? 'PD' : 'MD';
						},
						week : {
							dow : 1,
							doy : 4 
						}
					});
				
				 // Date Picker end 
				 
			</script>
			<?php } ?>

		<?php } ?>
		